data class Coffee(val Black:Boolean, val numberOfSuger: Int) {
}