public fun sum(a:Int, b:Int) = a+b

private fun sub(a:Int, b:Int) = a-b

/*protected fun mul(a:Int, b:Int) = a*b*/

internal fun div(a:Int,b:Int) = a/b