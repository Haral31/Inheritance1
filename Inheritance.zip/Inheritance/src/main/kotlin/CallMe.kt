class CallMe:MyInterface, NewInterface {

    override fun hello() {

        println("sudarshan says")

    }

    override fun love() {
        println("is spicel to me")
    }



}