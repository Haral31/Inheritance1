interface MyInterface {

    fun hello()

    fun greeating(){
        println("I love you")
    }

}