interface NewInterface {

    fun love()
}