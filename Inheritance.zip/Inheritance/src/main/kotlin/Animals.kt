open class Animals(var legs:Int, var color:String) {

    fun eat(){
        println("I love to eat")
    }

    fun sleep(){
        println("I love to sleep")
    }

   open fun sound(){
        println("l love sound")
    }



}