//import java.awt.Color

class Cats(legs:Int, color: String):Animals(legs, color) {
    override fun sound(){
        println("I furr")
    }
}